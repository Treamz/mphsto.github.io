$('.picture').fancybox({
 
});