$('.slider').slick({
    dots: true,
    arrows: false
});
          